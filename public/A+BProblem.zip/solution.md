# 题解

读入两个数直接相加，注意用 `long long`（a+b 可能超过 `int` 范围）。

```cpp
#include <bits/stdc++.h>
using namespace std;
int main(){ long long a,b; cin>>a>>b; cout << a+b << "\n"; }
```
